package it.zigbot

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.sqrt

data class VisionResult(
    val ballX: Int?, val ballY: Int?, val yellowPixels: Int,
    val confidence: Float, val suggestedTap: Boolean, val reason: String
)

/**
 * Conservative first-pass detector for the supplied Playus ZIG recording:
 * black ball + saturated yellow track on purple background.
 * This is deliberately observation-only until thresholds and timing are calibrated
 * against frames from the actual Xiaomi display.
 */
object GameVision {
    fun analyze(bitmap: Bitmap): VisionResult {
        val w = bitmap.width; val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        var yellowCount = 0
        var sx = 0L; var sy = 0L
        // Track top surface: yellow hue, high red/green, relatively low blue.
        for (y in (h * 0.12).toInt() until (h * 0.94).toInt()) {
            for (x in (w * 0.04).toInt() until (w * 0.96).toInt()) {
                val c = pixels[y * w + x]
                val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
                if (r > 175 && g > 135 && b < 115 && r > b * 1.5 && g > b * 1.25) yellowCount++
            }
        }
        // Ball candidate: compact dark components are approximated by a local darkness score.
        // Search middle/lower playfield, avoiding score/header and side UI.
        var bestX: Int? = null; var bestY: Int? = null; var bestScore = 0.0
        val x0 = (w * 0.12).toInt(); val x1 = (w * 0.88).toInt()
        val y0 = (h * 0.20).toInt(); val y1 = (h * 0.90).toInt()
        val step = maxOf(2, w / 180)
        val radius = maxOf(3, w / 65)
        for (cy in y0..y1 step step) for (cx in x0..x1 step step) {
            var dark = 0; var total = 0
            for (dy in -radius..radius step 2) for (dx in -radius..radius step 2) {
                if (dx * dx + dy * dy > radius * radius) continue
                val xx = cx + dx; val yy = cy + dy
                if (xx !in 0 until w || yy !in 0 until h) continue
                val c = pixels[yy * w + xx]
                val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
                if (r < 75 && g < 75 && b < 85) dark++
                total++
            }
            val score = if (total == 0) 0.0 else dark.toDouble() / total
            if (score > bestScore) { bestScore = score; bestX = cx; bestY = cy }
        }
        val confidence = (bestScore.coerceIn(0.0, 1.0) * 0.75 + if (yellowCount > w * h / 100) 0.25 else 0.0).toFloat()
        // No automatic decision is made yet: turn timing requires trajectory calibration.
        return VisionResult(bestX, bestY, yellowCount, confidence, false,
            "Rilevamento preliminare; trigger curva non calibrato")
    }
}
