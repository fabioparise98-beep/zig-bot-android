package it.zigbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.hardware.HardwareBuffer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class ZigAccessibilityService : AccessibilityService() {
    companion object {
        const val ACTION_OBSERVE = "it.zigbot.OBSERVE"
        const val ACTION_ARM = "it.zigbot.ARM"
        const val ACTION_STOP = "it.zigbot.STOP"
    }
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val running = AtomicBoolean(false)
    @Volatile private var armed = false
    private var lastLog = 0L

    private val receiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: android.content.Intent?) {
            when (intent?.action) {
                ACTION_OBSERVE -> { armed = false; startLoop() }
                ACTION_ARM -> { armed = true; startLoop() }
                ACTION_STOP -> { armed = false; running.set(false) }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val filter = android.content.IntentFilter().apply {
            addAction(ACTION_OBSERVE); addAction(ACTION_ARM); addAction(ACTION_STOP)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, android.content.Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(receiver, filter)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { armed = false; running.set(false) }

    private fun startLoop() {
        if (!running.compareAndSet(false, true)) return
        captureNext()
    }

    private fun captureNext() {
        if (!running.get()) return
        if (Build.VERSION.SDK_INT < 30) { running.set(false); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, executor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val buffer: HardwareBuffer = result.hardwareBuffer
                val bitmap = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                buffer.close()
                if (bitmap != null) {
                    val analysis = GameVision.analyze(bitmap)
                    bitmap.recycle()
                    val now = System.currentTimeMillis()
                    if (now - lastLog > 500) {
                        android.util.Log.i("ZIGBOT", "ball=${analysis.ballX},${analysis.ballY} yellow=${analysis.yellowPixels} conf=${analysis.confidence} armed=$armed ${analysis.reason}")
                        lastLog = now
                    }
                    // Safety gate: tap logic intentionally disabled until calibration.
                    // Never sends taps based only on the first-pass detector.
                }
                main.postDelayed({ captureNext() }, 100L)
            }
            override fun onFailure(errorCode: Int) {
                android.util.Log.w("ZIGBOT", "Screenshot failed: $errorCode")
                main.postDelayed({ captureNext() }, 250L)
            }
        })
    }

    @Suppress("unused")
    private fun tapCenter() {
        val path = Path().apply { moveTo(resources.displayMetrics.widthPixels / 2f, resources.displayMetrics.heightPixels / 2f) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 35)).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onDestroy() {
        armed = false; running.set(false)
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        executor.shutdownNow()
        super.onDestroy()
    }
}
