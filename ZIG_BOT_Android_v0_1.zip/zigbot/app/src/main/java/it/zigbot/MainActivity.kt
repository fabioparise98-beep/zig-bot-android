package it.zigbot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply {
            text = "ZIG BOT · prototipo 0.1\n\nPrima si calibra in modalità osservazione. L'automazione è disarmata per impostazione predefinita."
            textSize = 18f
        }
        val accessibility = Button(this).apply {
            text = "1 · Apri impostazioni Accessibilità"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val observe = Button(this).apply {
            text = "2 · Avvia osservazione (nessun tocco)"
            setOnClickListener { sendAction(ZigAccessibilityService.ACTION_OBSERVE) }
        }
        val arm = Button(this).apply {
            text = "3 · ARMA tocchi automatici (non ancora attivi)"
            setOnClickListener { sendAction(ZigAccessibilityService.ACTION_ARM) }
        }
        val stop = Button(this).apply {
            text = "STOP immediato"
            setOnClickListener { sendAction(ZigAccessibilityService.ACTION_STOP) }
        }
        layout.addView(title); layout.addView(accessibility); layout.addView(observe); layout.addView(arm); layout.addView(stop)
        setContentView(layout)
    }

    private fun sendAction(action: String) {
        sendBroadcast(Intent(action).setPackage(packageName))
    }
}
