plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "it.zigbot"
    compileSdk = 35
    defaultConfig {
        applicationId = "it.zigbot"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototype"
    }
}
