# ZIG BOT — Android prototype 0.1

Target: Android 11+ (API 30+), intended for the user's Xiaomi phone.

## What this prototype does
- Uses an Android AccessibilityService to request screen captures while the service is enabled.
- Runs a first-pass image detector for the **black ball** and **yellow track** seen in the supplied Playus ZIG gameplay.
- Logs ball candidates, yellow-pixel count and confidence to Logcat.
- Includes an explicit observe / arm / stop control flow.

## Important safety/status note
This is **not a finished playing bot** and it does **not send gameplay taps yet**. The tap routine is intentionally disconnected. The supplied online gameplay video does not reveal the original player's touch timestamps, and a single static colour detector is not enough to infer reliable turn timing, especially as speed increases. Enabling automatic taps before calibration could waste a daily attempt.

## Build
1. Open this folder in Android Studio (recent version with Android Gradle Plugin 8.7.3 support).
2. Let Gradle sync and install the debug build on the Xiaomi.
3. Open ZIG BOT and grant its Accessibility Service in Android Settings > Accessibility > Downloaded apps/services > ZIG BOT.
4. Open the app again and choose "Avvia osservazione". This performs screen analysis only; it does not tap.
5. While Playus is visible, inspect Logcat for tag `ZIGBOT`.

## Next calibration required
Capture an actual Playus ZIG run on the Xiaomi (preferably a practice/non-ranked run) with screen recording enabled. We need several turns and the actual display resolution. The next development step is to calibrate ball tracking and infer turn timing from successive frames, then validate in a local replay/test harness before connecting the tap routine.

## Controls
- Observe: screen capture + detector only.
- Arm: reserves the automation state, but taps remain disabled in this prototype.
- STOP: immediately stops the capture loop and disarms.

The app does not bypass Playus protections or access Playus account data. Android will require the user to explicitly enable the accessibility service.
